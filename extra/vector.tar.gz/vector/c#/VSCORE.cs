﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VectorSpace 
{
    class dimension
    {
        public Guid id;
        public float Value;
    }


    class dimensionList : Dictionary<Guid,dimension> {};

    class vector {
        public Guid id;
        public dimensionList dimensions = new dimensionList();
        System.Security.Cryptography.MD5CryptoServiceProvider hash = new System.Security.Cryptography.MD5CryptoServiceProvider();

        private string HashString(string Value)
        {
            byte[] data = System.Text.Encoding.ASCII.GetBytes(Value);
            data = hash.ComputeHash(data);
            string ret = "";
            ret = BitConverter.ToString(data).Replace("-", "") ; 
            return ret;
        }

        public Guid StringToGuid(string s)
        {
            return new System.Guid(HashString(s));
        }

        public void AddTextDimension(string id, float Value)
        {
            AddDimension(StringToGuid(id),Value);
        }

        public void AddDimension(Guid id, float Value){
           if(!dimensions.ContainsKey(id)){
            dimension d = new dimension();
            d.id = id;
            d.Value = Value;
            dimensions.Add(id,d);
           }
        }
        

    }

    class vectorlist : List<vector> { };

    class vectorWorker {

        public float dotProduct = (float)0.00;
        public float relativity = (float)0.00;
        public float relativeMagnitude = (float)0.00;
        public float similarity = (float)0.00;



        public float CalcRelativeMagnitude(vector A, vector B)
        {
            float vv = 0;
            float result = 0;
            dimension dest;
            foreach (KeyValuePair<Guid, dimension> kvp in A.dimensions)
            {
                dimension source = kvp.Value;
                if (B.dimensions.TryGetValue(source.id,out dest)){ 
                    vv = dest.Value;
                    result += (vv * vv);
                }
            }
            return (float)Math.Sqrt(result);
        }

        public float CalcRelativity(vector A, vector B)
        { 
            float result = 0;
            dimension dest;
            foreach (KeyValuePair<Guid, dimension> kvp in A.dimensions)
            {
                dimension source = kvp.Value;
                float vv = source.Value;
                if (B.dimensions.TryGetValue(source.id, out dest))
                {                
                    float dv = dest.Value ;
                    if (vv * dv > 0) { result += 1; }
                }
            }
            return (float)result;
        }


        public float CalcDotProduct(vector A, vector B)
        {
            float result = 0;
            dimension dest;
            foreach (KeyValuePair<Guid, dimension> kvp in A.dimensions)
            {
                dimension source = kvp.Value;
                float vv = source.Value;
                if (B.dimensions.TryGetValue(source.id, out dest))
                {             
                    float dv = dest.Value;
                    result += (dv * vv);
                }
            }
            return (float)result;

        }

        public float RelativeQueryCosine(vector A, vector B){
            float m1 = CalcRelativeMagnitude(A, B);
            float m2 = CalcRelativeMagnitude(B, A);
            float mt = m1 * m2;
            relativeMagnitude = mt;
            float result = 0;
            if (mt != 0)
            {
                dotProduct = CalcDotProduct(A, B);
                result = dotProduct / mt;
                relativity = 0;
                if (A.dimensions.Count > 0)
                {
                    float arel = A.dimensions.Count;
                    float brel = CalcRelativity(A, B);
                    relativity = (brel / arel);
                    result = result * relativity; //more matching dims gives better score.
                }
                similarity = result;
                return result;
            }
            return 0;
        }

        public vectorlist Query(vector Q, vectorlist List, float threshold){
            vectorlist v = new vectorlist();
            foreach (vector vect in List)
            {
                if (RelativeQueryCosine(Q,vect) > threshold)
                {
                    v.Add(vect);
                }

            }
            return v;
        }



    }


}
