﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TermVectorSpace
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vector Query = new vector();

            vectorWorker worker = new vectorWorker();
            vectorlist Result;
            Output.Text = ""; Application.DoEvents();

            Output.Text += "Querying.\r\n"; Application.DoEvents();
            Application.DoEvents();
            Query.AddTextDimension("DOG", 1);
            Query.AddTextDimension("Collie", 1);
            Query.AddTextDimension("vertebrate", 1);

            Result = worker.Query(Query, Source,(float) 0.5);

            Output.Text += "Done.\r\n"; Application.DoEvents();
             
        }


        vectorlist Source = new vectorlist();

        private void button2_Click(object sender, EventArgs e)
        {
            vector Sample = new vector();
            int max = 1000000 ;
            Output.Text += "Adding " + max + " vectors\r\n";
            Application.DoEvents();

            Guid dog = Sample.StringToGuid("DOG");
            Guid collie = Sample.StringToGuid("Collie");
            Guid vertebrate = Sample.StringToGuid("vertebrate");

            for (int i = 0; i < max; i++)
            {
                Sample.AddDimension(dog, 1);
                Sample.AddDimension(collie, 1);
                Sample.AddDimension(vertebrate, 1);
                Sample.id = Guid.NewGuid();
                Source.Add(Sample);
                if (i % 10000 == 0) { Output.Text += "    " + i + "\r\n"; Output.Select(Output.Text.Length + 1, 2); Output.ScrollToCaret(); Application.DoEvents(); }
            }

        }
    }
}
