-module(vectorspace).
-import(lists).
-export([vector_dimension/2,dot_product/2,test_dotproduct/0,relative_magnitude/2,
            test_vectorspace_query/0,vectorspace_add/2,vectorspace_query/3,test_idf_map/0,create_vector/1,vector_dimensions/2,reduce_vectorspace/1,test_reduce/0]).

-record(dimension,{dimensionid="00000000000000000000000000000000",value=0}).
-record(vector,{vectorid="00000000000000000000000000000000",dimensions=[]}).
  

create_vector(VectorID) -> #vector{vectorid=VectorID}.
vector_dimensions(V,Dims) -> V#vector{dimensions=Dims}.

%% ******************************* GENERAL PURPOSE FUNCTIONS
vector_dimension(Name,Value) -> 
 #dimension{dimensionid=Name,value=Value}.



%% ******************************* DOT PRODUCT
dimension_sum_value ([TOTAL|V]) -> TOTAL#dimension.value + dimension_sum_value(V);
dimension_sum_value ([]) -> 0.
dot_product_list(VectorA,VectorB) ->
  [ {dimension,A#dimension.dimensionid,(A#dimension.value * B#dimension.value)} || A <- VectorA#vector.dimensions, B<-VectorB#vector.dimensions ,A#dimension.dimensionid==B#dimension.dimensionid ].
dot_product(VectorA,VectorB) ->
    Dims = dot_product_list(VectorA,VectorB),
    dimension_sum_value(Dims).



%% ******************************* RELATIVE MAGNITUDE
dimension_sum_sqr  ([TOTAL|V]) -> (TOTAL#dimension.value * TOTAL#dimension.value) + dimension_sum_sqr(V);
dimension_sum_sqr  ([]) -> 0.
dimensions_B_which_exist_in_A (VectorA,VectorB)->
    [ B || A <- VectorA#vector.dimensions, B<-VectorB#vector.dimensions ,A#dimension.dimensionid==B#dimension.dimensionid ].
relative_magnitude (VectorA,VectorB)->
   Dims = dimensions_B_which_exist_in_A (VectorA,VectorB),
   math:sqrt(dimension_sum_sqr(Dims)).


%% ******************************* DIMENSIONAL RELATIVITY (# of dims difference)
dimension_relativity (VectorA,VectorB) ->
      Dims = dimensions_B_which_exist_in_A (VectorA,VectorB),
      length(Dims).


%% ******************************* RELATIVE QUERY COSINE - the "score" of two vectors.


relative_query_cosine(VectorA,VectorB)->
    M1 = relative_magnitude(VectorA,VectorB),
    M2 = relative_magnitude(VectorB,VectorA),
    MT = M1 * M2,
    if (MT/=0)->
          DotProduct=dot_product(VectorA,VectorB),
          Result = DotProduct / MT,
          Arel = length(VectorA#vector.dimensions),
          if
            (Arel/=0)->
               Brel = dimension_relativity(VectorA,VectorB),
               Relativity = (Brel / Arel);
            (Arel==0)->
               Relativity = 0
          end,
          (Relativity * Result);
       (MT==0)->
          0
    end.

test_dotproduct() ->
  VA = #vector{vectorid= "somevector" },
  VB = #vector{vectorid= "somevector2" },
  Dims = [vector_dimension("dog",4),vector_dimension("cat",3)],
  VAb =VA#vector{dimensions=Dims},
  Dims2 = [vector_dimension("dog",4),vector_dimension("cat",6)],
  VBb =VB#vector{dimensions=Dims2},
  io:format("~p~n",[relative_query_cosine(VAb,VBb)]).



%% *******************************  VECTORSPACE Query  (vectorspace is a list of Vectors)

vectorspace_add (Vector,VectorSpace) ->  [Vector|VectorSpace].


vectorspace_query(Query,Vectorspace,Threshold) ->
   [ {Vector,relative_query_cosine(Query,Vector)}  || Vector <- Vectorspace , relative_query_cosine(Query,Vector)>Threshold].
 

test_vectorspace_query() ->
  VA = #vector{vectorid= "somevector" },
  VB = #vector{vectorid= "somevector2" },
  Dims = [vector_dimension("dog",4),vector_dimension("cat",3)],
  VAb =VA#vector{dimensions=Dims},
  Dims2 = [vector_dimension("dog",4),vector_dimension("cat",6)],
  VBb =VB#vector{dimensions=Dims2},
  Vectorspace = vectorspace_add(VAb,[]),
  VectorspaceB = vectorspace_add(VBb,Vectorspace),

  Q = #vector{vectorid= "somevector3" },
  QDims = [vector_dimension("dog",4),vector_dimension("cat",3)],
  Qb =Q#vector{dimensions=QDims},

  vectorspace_query(Qb,VectorspaceB,0.99).




  %% ***************************** BUILD IDF map for a vectorspace

build_idf_map([],Result)-> Result;

build_idf_map([Dim|IDF],Result)->
     IDFDim = lists:keysearch(Dim#dimension.dimensionid,2,Result),
     case IDFDim of
       {_, Tuple} -> DoAdd= #dimension{dimensionid=Dim#dimension.dimensionid,value=Tuple#dimension.value+Dim#dimension.value},
                     build_idf_map(IDF,[DoAdd|lists:delete(Tuple,Result)]);
       false-> DoAdd=Dim,
                     build_idf_map(IDF,[DoAdd|Result])
     end.

total_idf([],_)-> 0;
total_idf([Dim|IDF],Result)->
         Dim#dimension.value + total_idf(IDF,Result).

build_adjusted_map(Map,Total_Frequency)->
  [ Dim#dimension{ value = Dim#dimension.value / Total_Frequency}  || Dim  <- Map ].

create_idf_map(Vectorspace) ->
  IDF=[],
  Map = build_idf_map(lists:append( [
                   [ Dim || Dim <- Vector#vector.dimensions ]
            || Vector <- Vectorspace]),IDF),
  Total_Frequency = total_idf(Map,{}),
  build_adjusted_map(Map,Total_Frequency).



combine_dimension_and_idf_map(Dimension,IDFmap)->
   [  Dimension#dimension{value=Dimension#dimension.value * Idf#dimension.value}  || Idf <- IDFmap, Idf#dimension.dimensionid==Dimension#dimension.dimensionid].

combine_vector_and_idf_map (Vector,IDFmap) ->
   lists:merge( [ combine_dimension_and_idf_map(Dim,IDFmap)  || Dim <- Vector#vector.dimensions]).


combine_vectorspace_and_idf_map (Vectorspace,IDFmap)->
   [ Vector#vector{dimensions=combine_vector_and_idf_map(Vector,IDFmap) } || Vector <- Vectorspace].

  
process_merge_dimension(A,B)->
         Aid = A#dimension.dimensionid, 
         Bid = B#dimension.dimensionid,
         io:format("    COMPARE:(~p , ~p)~n",[Aid,Bid]),
         if
           Aid==Bid -> 
                #dimension{dimensionid=Aid,value=A#dimension.value+B#dimension.value};
           Aid/=Bid ->
                A
         end.

merge_dimension(A,[])-> [A]; 
merge_dimension(A,Dimensions)-> 
       [ process_merge_dimension(A,B)
       || B <-
       Dimensions].

merge_dimensions([Dim|DimensionsA],DimensionsB)->
       io:format("  DIM:~p~n",[Dim]),
       NewDimensionsB = merge_dimension(Dim,DimensionsB),
       io:format("  RESULT:~p~n",[NewDimensionsB]),
       merge_dimensions(DimensionsA,NewDimensionsB);
merge_dimensions([],DimensionsB)-> DimensionsB.           


reduce_vectorspace_dimensions([Vector|Vectorspace],Reduced)->
       io:format("Vector:~p~n",[Vector#vector.dimensions]),
      NewReduced = merge_dimensions(Vector#vector.dimensions, Reduced),
      reduce_vectorspace_dimensions(Vectorspace,NewReduced);
reduce_vectorspace_dimensions([],Reduced)-> Reduced.


reduce_vectorspace(Vectorspace)->
       #vector{dimensions=reduce_vectorspace_dimensions(Vectorspace,[])}.



test_idf_map()->
  VA = #vector{vectorid= "somevector" },
  VB = #vector{vectorid= "somevector2" },
  Dims = [vector_dimension("dog",4),vector_dimension("cat",3)],
  VAb =VA#vector{dimensions=Dims},
  Dims2 = [vector_dimension("dog",4),vector_dimension("cat",6)],
  VBb =VB#vector{dimensions=Dims2},
  Vectorspace = vectorspace_add(VAb,[]),
  VectorspaceB = vectorspace_add(VBb,Vectorspace),
  IDFmap = create_idf_map(VectorspaceB),
  combine_vectorspace_and_idf_map(VectorspaceB,IDFmap).


test_reduce()->
  VA = #vector{vectorid= "somevector" },
  VB = #vector{vectorid= "somevector2" },
  Dims = [vector_dimension("dog",4),vector_dimension("cat",3)],
  VAb =VA#vector{dimensions=Dims},
  Dims2 = [vector_dimension("dog",4),vector_dimension("cat",6)],
  VBb =VB#vector{dimensions=Dims2},
  Vectorspace = vectorspace_add(VAb,[]),
  VectorspaceB = vectorspace_add(VBb,Vectorspace),
  IDFmap = create_idf_map(VectorspaceB),
  Adjusted = combine_vectorspace_and_idf_map(VectorspaceB,IDFmap),
  reduce_vectorspace(Adjusted).

