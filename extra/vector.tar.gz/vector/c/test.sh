gcc -g3 -Wall -O3 uuid.c vs_dimensionindex.c vs_core.c test_core.c -ldl -o test_core -lm -pg
