#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include "vs_core.h"


int gettickcount(){
 struct timeval tv;
 long milliseconds;             
 struct tm* ptm;
 int result;

 /* Obtain the time of day, and convert it to a tm struct. */
 gettimeofday (&tv, NULL);
 ptm = localtime (&tv.tv_sec);
 milliseconds = tv.tv_usec  ;
 result = (int)milliseconds;
 return(result) ;
}


int main(){
  int i;
  float mag,dp,cs;

  t_uuid id,dim,d2,d3;
  vector *v,*clone;
  vs_value val ;
  dimension *d;
  i=0;

  dim = newid();
  printf("Testing Vector Core:\n");
  id = newid();
  printf("Prepare space for a vector with 3 dimensions.\n");
  v =  vs_createvector (id,3);

  printf("testing for 3 dimensions.\n");
  if( v->dimensioncount==3 ){ printf("***PASS\n");} else {printf("***FAIL\n");}
  val.floatvalue = 100;

  printf("Set a value on Dim 0.\n");
  if(vs_setvalue (v,dim,val)== 1){printf("*** PASS\n");} else {printf("*** FAIL\n");}

  d2=newid();
  d3=newid();
  val.floatvalue=100;
  vs_setvalue (v,d2,val);
  vs_setvalue (v,d3,val);

  printf("Read back the same value.\n");
  d=vs_getvalue(v,dim);
  if (d->value.floatvalue==val.floatvalue){printf("*** PASS\n");} else {printf("*** FAIL\n");}
  printf("Clone the vector, destroy it, and read back the same dimension from clone.\n");
  clone = vs_createvector (id,3);

  if (vs_clone (v,clone)==1){printf("*** PASS clone\n");} else {printf("*** FAIL clone\n");}
  if (vs_destroyvector (&v) ==1){printf("*** PASS destroy\n");} else {printf("*** FAIL destroy\n");}
  d=vs_getvalue(clone,dim);
  if (d->value.floatvalue==val.floatvalue){printf("*** PASS read\n");} else {printf("*** FAIL read\n");}
  printf("Set some values on the cloned vector and calculate magnitude (1 dim, mag should == value).\n");
  if(vs_setvalue (clone,dim,val)== 1){printf("*** PASS setvalue\n");} else {printf("*** FAIL setvalue\n");}
  mag=vs_magnitude(clone);
  if (mag>0){printf("*** PASS magnitude\n");} else {printf("*** FAIL magnitude\n");}
  printf("Clone the vector, and do dotproduct and cosine.\n");

  if (vs_clone (clone,v)==1){printf("*** PASS clone\n");} else {printf("*** FAIL clone\n");}

printf("Testing all 1,000,000 dimensions...\n");
for (i=0;i<1000000;i++){
  dp = vs_dotproduct(clone,v);
  cs = vs_cosine(clone,v);
}

// The "production comparison" is
// score = vs_relativequerycosine(vector *a,vector *b,float *dp).
// dp is an output parameter, so you get the score and the dotproduct in one go.

  if (cs==1){printf("*** PASS cosine value=%f\n",cs);} else {printf("*** FAIL cosine value=%f\n",cs);}



  return(0);
}
