#ifdef WIN32
typedef unsigned long   ulg;
typedef unsigned int    uint;
typedef unsigned short    ushort;
typedef          double real;
typedef          float  sreal;
typedef     long double lreal;
typedef unsigned char   byte;
typedef   signed char   sbyte;
typedef   signed char   bool;
#endif

